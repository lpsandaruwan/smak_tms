-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 21, 2015 at 08:32 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `smaktms`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyvehicle`
--

CREATE TABLE IF NOT EXISTS `companyvehicle` (
  `id` int(11) NOT NULL,
  `vehid` int(11) NOT NULL,
  `insuranceid` int(11) NOT NULL,
  `leasingid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` varchar(11) NOT NULL,
  `title` varchar(10) NOT NULL,
  `fullname` varchar(60) NOT NULL,
  `nic` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `tellno` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `drivinlicno` varchar(50) NOT NULL,
  `drivinlictype` varchar(50) NOT NULL,
  `licissued` date NOT NULL,
  `licexpired` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `title`, `fullname`, `nic`, `dob`, `address`, `tellno`, `gender`, `type`, `drivinlicno`, `drivinlictype`, `licissued`, `licexpired`) VALUES
('0', '', '0', '0', '0000-00-00', '0', '0', '', 'cleaner', '', '', '0000-00-00', '0000-00-00'),
('1212121', '', 'afdeafr', '21434134', '1992-01-11', 'fdadva', '23123', '', 'assistant', '', '', '0000-00-00', '0000-00-00'),
('14314314314', '', 'fmndof', '34134', '1992-02-10', 'dmfodsv', '1312', '', 'assistant', '', '', '0000-00-00', '0000-00-00'),
('22222222222', '', '', '', '0000-00-00', '', '', '', 'assistant', '', '', '0000-00-00', '0000-00-00'),
('3242432', '', 'dfdsgsfg', '24334324', '2002-01-21', 'wfgfffffffdgbsf', '123214', '', 'driver', 'ewfewgf', 'wefwg', '2003-01-11', '2003-02-11'),
('TUE1102', '', 'Lahiru Pathirage', '929292929292v', '1992-02-10', 'Kosswatta road, Arakawila, Handapangoda', '0713092239', '', 'driver', '2333333334', 'Car', '2000-02-12', '2005-03-01'),
('TUE1103', '', 'Lahiru Pathirage', '929292929292v', '1992-02-10', 'Kosswatta road, Arakawila, Handapangoda', '0713092239', '', 'driver', '2333333334', 'Car', '2000-02-12', '2005-03-01'),
('TUE1212', '', 'isgdiafhkj', '476565768', '1992-02-10', 'hjghgkkh,jjkhj', '3124314', '', 'driver', '124134', '124134', '2011-11-11', '2011-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `hiredvehicle`
--

CREATE TABLE IF NOT EXISTS `hiredvehicle` (
  `id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `ownid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hiredvehicle`
--

INSERT INTO `hiredvehicle` (`id`, `vid`, `ownid`) VALUES
(234234, 23444234, 0),
(2222222, 22222, 22222222),
(33333333, 3333333, 0),
(2147483647, 2147483647, 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `hiredvehicleowner`
--

CREATE TABLE IF NOT EXISTS `hiredvehicleowner` (
  `oid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `nic` varchar(50) NOT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hiredvehicleowner`
--

INSERT INTO `hiredvehicleowner` (`oid`, `name`, `address`, `phone`, `nic`) VALUES
(22222222, '222222', '2222', 222, '2222222'),
(2147483647, '111111111111', '111111111111', 2147483647, '1111111111111111');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE IF NOT EXISTS `vehicle` (
  `vid` int(11) NOT NULL,
  `blength` float NOT NULL,
  `capacity` float NOT NULL,
  `priceval` float NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vid`, `blength`, `capacity`, `priceval`) VALUES
(22222, 0, 0, 0),
(3333333, 0, 0, 0),
(23444234, 0, 0, 0),
(2147483647, 0, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
